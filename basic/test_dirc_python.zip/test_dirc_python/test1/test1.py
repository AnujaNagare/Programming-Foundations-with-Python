class test1:
	def __init__(self):
		print("Hello this is test 1")

test1()