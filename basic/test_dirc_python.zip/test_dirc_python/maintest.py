# from test1.test1 import *
# from test2.test2 import *

class maintest:
	def __init__(self):
		print("Hello this is main test")

maintest()
