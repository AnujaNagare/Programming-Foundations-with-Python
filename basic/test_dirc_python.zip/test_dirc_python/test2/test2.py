from test1.test1 import *
from maintest import *
# export PYTHONPATH=/Users/anujanagare/Thesis/Update/March2018/8thMarch/test_dirc_python/:$PYTHONPATH

class test2:
	def __init__(self):
		print("Hello this is test 2")

test2()